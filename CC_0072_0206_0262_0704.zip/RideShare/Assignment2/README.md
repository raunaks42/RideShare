### Running RideShare on Containers
#### Instructions
- Install Docker & Docker Compose (Docker Desktop includes Docker Compose)
- Run ```docker-compose up --build```

